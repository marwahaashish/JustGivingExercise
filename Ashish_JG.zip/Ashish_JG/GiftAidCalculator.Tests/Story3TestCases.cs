﻿using GiftAidCalculator.TestConsole;
using NUnit.Framework;

namespace GiftAidCalculator.Tests
{
    [TestFixture]
    class Story3TestCases
    {   
        /// <summary>
        /// Helper function to roundoff the amount as per the number of places provided.
        /// </summary>
        [TestCase]        
        public void Return_Aid_Round_Off_Amount()
        {
            var actuavalue = CommonHelper.RoundOff(2.22222m, 2);
            Assert.AreEqual(2.22, actuavalue);
        }
      
    }
}
