﻿using System;
using GiftAidCalculator.TestConsole;
using Moq;
using NUnit.Framework;

namespace GiftAidCalculator.Tests
{


    [TestFixture]
    public class Story2TestCases
    {
        /// <summary>
        /// Test to update the tax rate and thereafter calculating the updated aid amount as per updated tax rate.
        /// </summary>
        [TestCase]
        public void UpdateTaxRate()
        {
            IGiftAidRepository taxRepo = new TaxRateRepository();

            var oldrate = taxRepo.GetTaxRate();
            Assert.AreEqual(20, oldrate.CurrentRate);

            taxRepo.UpdateTaxRate(40);
            var updatedCurrentRate = taxRepo.GetTaxRate();
            Assert.AreEqual(40, updatedCurrentRate.CurrentRate);

            IGiftAid aidcalc = new GiftAid(taxRepo);
            var giftAidAmount = aidcalc.GetGiftAidAmount(100);
            Assert.AreEqual(66.67, giftAidAmount);

        }

    }
}
