﻿using System;
using GiftAidCalculator.TestConsole;
using Moq;
using NUnit.Framework;

namespace GiftAidCalculator.Tests
{
    [TestFixture]
    public class Story1TestCases
    {
        /// <summary>
        /// To calculate gift aid amount at 20 % tax rate.
        /// </summary>
        [Test]
        public void GetGiftAidAmountForTaxRate20()
        {

            const decimal donationAmount = 100;

            var taxRateRepo = new Mock<IGiftAidRepository>();

            taxRateRepo.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 20 });

            var giftAidCalculator = new GiftAid(taxRateRepo.Object);

            var actualGiftAidAmount = giftAidCalculator.GetGiftAidAmount(donationAmount);

            Assert.That(Math.Round(actualGiftAidAmount, 2), Is.EqualTo(25));
        }

        /// <summary>
        /// To calculate gift aid when donation amount entered is zero. 
        /// </summary>
        [Test]
        public void GetGiftAidAmountForZeroDonation()
        {

            const decimal donationAmount = 0;

            var taxRateRepository = new Mock<IGiftAidRepository>();

            taxRateRepository.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 50 });

            var giftAidCalculator = new GiftAid(taxRateRepository.Object);

            var actualGiftAidAmount = giftAidCalculator.GetGiftAidAmount(donationAmount);

            Assert.That(actualGiftAidAmount, Is.EqualTo(0));
        }


        [Test]
        public void GetGiftAidAmountForNegativeDonation()
        {

            const decimal donationAmount = -1;
            var taxRateRepository = new Mock<IGiftAidRepository>();


            taxRateRepository.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 20 });

            var giftAidCalculator = new GiftAid(taxRateRepository.Object);

            var actualGiftAidAmount = giftAidCalculator.GetGiftAidAmount(donationAmount);
            
            Assert.That(actualGiftAidAmount, Is.EqualTo(0));
        }

        /// <summary>
        /// Test for checking the boundry conditions.
        /// </summary>
        [Test]
        public void GetGiftAidAmountForTaxRateBoundry()
        {

            const decimal donationAmount = 100;
            var taxRateRepository = new Mock<IGiftAidRepository>();


            taxRateRepository.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 100 });

            var giftAidCalculator = new GiftAid(taxRateRepository.Object);
            
            Assert.Throws<DivideByZeroException>(new TestDelegate(() => giftAidCalculator.GetGiftAidAmount(donationAmount)));
        }




    }


}
