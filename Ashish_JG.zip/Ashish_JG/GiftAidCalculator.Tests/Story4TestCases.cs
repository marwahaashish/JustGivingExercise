﻿using GiftAidCalculator.TestConsole;
using Moq;
using NUnit.Framework;


namespace GiftAidCalculator.Tests
{
    /// <summary>
    /// Test case for story 4 for event type
    /// </summary>
    [TestFixture]
    class Story4TestCases
    {
        /// <summary>
        /// Calculate gift aid amount when event type is swimming.
        /// </summary>
        [Test]
        public void GetGiftAidAmountForSwimmingEvent()
        {

            var taxRateRepository = new Mock<IGiftAidRepository>();
            var taxRate = taxRateRepository.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 30 });
            IGiftAid giftAid = new GiftAid(taxRateRepository.Object);

            var swimmingEvent = EventFactory.GetEventFactory(EventCategory.Swimming, giftAid);
            var giftAidAmountAfterSupplement = swimmingEvent.GetGiftAidAmount(100);
            Assert.AreEqual(42.87, giftAidAmountAfterSupplement);

        }

        /// <summary>
        /// Calculate gift aid amount when event type is Running.
        /// </summary>
        [Test]
        public void GetGiftAidAmountForRunningEvent()
        {

            var taxRateRepository = new Mock<IGiftAidRepository>();
            var taxRate = taxRateRepository.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 20 });
            IGiftAid giftAid = new GiftAid(taxRateRepository.Object);

            var runningEvent = EventFactory.GetEventFactory(EventCategory.Running, giftAid);
            var giftAidAmountAfterSupplement = runningEvent.GetGiftAidAmount(100);
            Assert.AreEqual(25.01, giftAidAmountAfterSupplement);

        }

        /// <summary>
        /// Calculate gift aid amount when no event type.
        /// </summary>
        [Test]
        public void GetGiftAidAmountWithoutSupplement()
        {

            var taxRateRepository = new Mock<IGiftAidRepository>();
            var taxRate = taxRateRepository.Setup(x => x.GetTaxRate()).Returns(new TaxRate { CurrentRate = 20 });
            IGiftAid giftAid = new GiftAid(taxRateRepository.Object);

            var withoutSupplementEvent = EventFactory.GetEventFactory(EventCategory.None, giftAid);
            var giftAidAmountAfterSupplement = withoutSupplementEvent.GetGiftAidAmount(100);
            Assert.AreEqual(25.00, giftAidAmountAfterSupplement);

        }

    }
}
