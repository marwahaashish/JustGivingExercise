﻿
namespace GiftAidCalculator.TestConsole
{
    public class TaxRate
    {
        public decimal CurrentRate;
    }
}
