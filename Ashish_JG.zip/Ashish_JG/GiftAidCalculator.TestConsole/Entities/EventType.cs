﻿
namespace GiftAidCalculator.TestConsole
{
    public enum EventCategory { Running, Swimming, None };
   public class EventType
    {
       public EventCategory Name;
        public int SupplementPercentage;
    }
}
