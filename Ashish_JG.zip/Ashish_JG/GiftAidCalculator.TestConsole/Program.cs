﻿using GiftAidCalculator.TestConsole;
using System;

namespace GiftAidCalculator.TestConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            IGiftAid giftAidCalulation = new GiftAid(new TaxRateRepository());
            IGiftAid eventWithSupplement;
            EventCategory eventType;
            decimal donationAmount;
            
            Console.WriteLine("Please Enter donation amount:");
            Decimal.TryParse(Console.ReadLine(), out donationAmount);    

            Console.WriteLine("Please Enter the event type for donation. Enter 1 for running(get extra supplement), 2 for swimming(get extra supplement) and 3 for others:");            
            if (Enum.TryParse<EventCategory>(Console.ReadLine(), out eventType))
            {
                eventWithSupplement= EventFactory.GetEventFactory(eventType,giftAidCalulation);
              
            }
            else
            {
                Console.WriteLine("Please enter the valid event type");
            }

            Console.WriteLine("Press any key to exit.");
            Console.ReadLine();
        }


    }
}
