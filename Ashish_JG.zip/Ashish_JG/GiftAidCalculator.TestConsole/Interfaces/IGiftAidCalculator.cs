﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GiftAidCalculator.TestConsole
{
    public interface IGiftAid
    {
        decimal GetGiftAidAmount(decimal donationAmount);
    }   
}
