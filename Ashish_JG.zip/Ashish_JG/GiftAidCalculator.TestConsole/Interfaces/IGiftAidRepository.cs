﻿using GiftAidCalculator.TestConsole;

namespace GiftAidCalculator.TestConsole
{
    public interface IGiftAidRepository
    {
       TaxRate GetTaxRate();
       void UpdateTaxRate(decimal udatedTaxRate);  
    }
}
