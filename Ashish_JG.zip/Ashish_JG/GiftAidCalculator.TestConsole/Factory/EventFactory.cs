﻿
namespace GiftAidCalculator.TestConsole
{
    public static class EventFactory
    {
        public static IGiftAid GetEventFactory(EventCategory eventType, IGiftAid giftAid)
        {
            IGiftAid eventWithSupplement;
            switch (eventType)
            {
                case EventCategory.Running:
                    eventWithSupplement = new RunningEvent(giftAid);

                    break;
                case EventCategory.Swimming:
                    eventWithSupplement = new SwimmingEvent(giftAid);
                    break;
                default:
                    eventWithSupplement = giftAid;
                    break;
            }
            return eventWithSupplement;
        }
    }
}