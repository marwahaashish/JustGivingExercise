﻿using System;

namespace GiftAidCalculator.TestConsole
{
   public static class CommonHelper 
    {
             
       public static decimal RoundOff(decimal amount,int noofdDecimalPlace)
        {
            return Math.Round(amount, noofdDecimalPlace);
        }
    }
}
