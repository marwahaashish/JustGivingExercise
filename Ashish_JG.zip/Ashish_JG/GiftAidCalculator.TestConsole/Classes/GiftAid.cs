﻿using System;
using GiftAidCalculator.TestConsole;

namespace GiftAidCalculator.TestConsole
{
    public class GiftAid : IGiftAid
    {
        //public TaxRate CurrentTaxRate { get; set; }
        private IGiftAidRepository taxRateRepository;
        public GiftAid(IGiftAidRepository taxRateRepo)
        {
            taxRateRepository = taxRateRepo;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="donationAmount"></param>   
        /// <returns></returns>
        /// <exception cref="DivideByZeroException"></exception>
        public  decimal GetGiftAidAmount(decimal donationAmount)
        {
            if (donationAmount > 0.0m)
            {
                var taxRate = taxRateRepository.GetTaxRate();
                return CommonHelper.RoundOff(donationAmount * (taxRate.CurrentRate / (100 - taxRate.CurrentRate)),2);
            }
            else
            {
                return 0.0m;
            }
        }
    }
}
