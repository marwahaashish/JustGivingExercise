﻿
namespace GiftAidCalculator.TestConsole
{

    public class TaxRateRepository : IGiftAidRepository
    {
        public static TaxRate CurrentTaxRate { get; set; }

        static TaxRateRepository()
        {
            CurrentTaxRate = new TaxRate { CurrentRate = 20 };
        }
        /// <summary>
        /// Fetches the tax rate from DB
        /// </summary>
        /// <returns></returns>
        public TaxRate GetTaxRate()
        {
            //TODO: write code to fetch tax rate from any data-store (Excel/Configuration/DB)          
            return CurrentTaxRate;
        }

        public void UpdateTaxRate(decimal updatedTaxRate)
        {
            CurrentTaxRate.CurrentRate = updatedTaxRate;
           
        }
    }
}
