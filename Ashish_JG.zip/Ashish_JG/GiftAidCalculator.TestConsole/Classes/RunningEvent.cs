﻿using GiftAidCalculator.TestConsole;

namespace GiftAidCalculator.TestConsole
{
    public class RunningEvent : IEvent
    {
        IGiftAid giftaid;
        //private int _supplementPercent;
        public RunningEvent(IGiftAid giftaid)
        {
            this.giftaid = giftaid;
        }
        public decimal GetGiftAidAmount(decimal donationAmount)
        {
            return giftaid.GetGiftAidAmount(donationAmount + (SupplementPercent));
        }

        public decimal SupplementPercent
        {
            get
            {
                return .05m;
            }
        }
    }

    public class SwimmingEvent : IEvent
    {
        IGiftAid giftaid;
        //private int _supplementPercent;
        public SwimmingEvent(IGiftAid giftaid)
        {
            this.giftaid = giftaid;
        }
        public decimal GetGiftAidAmount(decimal donationAmount)
        {
            return giftaid.GetGiftAidAmount(donationAmount + (SupplementPercent));
        }

        public decimal SupplementPercent
        {
            get
            {
                return .03m;
            }
        }
    }
}
